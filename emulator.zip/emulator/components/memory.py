import collections
import enum
from peripherals.display import Display

class IllegalAccessMemoryError(MemoryError):
    def __init__(self, addr):
        message = f"Illegal access at {addr:04x}"
        super().__init__(message)

class SpaceMemoryError(MemoryError):
    def __init__(self):
        message = f"Not enought memory to continue"
        super().__init__(message)

class ReadMemoryError(MemoryError):
    def __init__(self, addr):
        message = f"Attempted to read at {addr:04x}"
        super().__init__(message)

class WriteMemoryError(MemoryError):
    def __init__(self, addr):
        message = f"Attempted to write at {addr:04x}"
        super().__init__(message)

class ExecuteMemoryError(MemoryError):
    def __init__(self, addr):
        message = f"Attempted to execute at {addr:x}"
        super().__init__(message)

class Memory(collections.UserList):
    SIZE    = 0x1000
    O_ROM   = 0x0200
    O_STACK = 0x0EA0

    class Permission(enum.IntEnum):
        EXECUTE     = 1
        READ        = 2
        WRITE       = 4

    def __init__(self):
        super().__init__()
        self.errors = {
            Memory.Permission.EXECUTE: ExecuteMemoryError,
            Memory.Permission.READ: ReadMemoryError,
            Memory.Permission.WRITE: WriteMemoryError
        }
        self.permission = []
        self.data = bytearray(self.SIZE)
        self.reset()

    def check(self, addr, wanted):
        for start, end, op in self.permission:
            if start <= addr < end:
                if op & wanted:
                    return True
                raise self.errors[wanted](addr)
        raise IllegalAccessMemoryError(addr)        

    def read(self, addr):
        if self.check(addr, self.Permission.READ) is True:
            return self.data[addr]
        raise RuntimeError

    def execute(self, addr):
        if self.check(addr, self.Permission.EXECUTE) is True:
            return self.data[addr]
        raise RuntimeError

    def write(self, addr, v):
        if 0 <= v <= 0xFF:
            if self.check(addr, self.Permission.WRITE) is True:
                self.data[addr] = v
            else:
                raise RuntimeError
        else:
            raise RuntimeError

    def load_fonts(self):
        self.data[0:len(Display.FONTS)] = Display.FONTS
        self.permission.append(
            (
                0,
                len(Display.FONTS),
                Memory.Permission.READ
            )
        )

    def load_stack(self):
        self.permission.append(
            (
                self.O_STACK,
                self.SIZE,
                Memory.Permission.READ | Memory.Permission.WRITE
            )
        )

    def load_rom(self, fd_rom):
        maxsize = self.O_STACK - self.O_ROM
        for i in range(maxsize):
            if (b := fd_rom.read(1)):
                self.data[self.O_ROM + i] = b[0]
            else:
                break
        else:
            raise SpaceMemoryError("rom")

        self.permission.append(
            (
                self.O_ROM,
                self.O_ROM + i,
                Memory.Permission.READ | Memory.Permission.EXECUTE
            )
        )

    def reset_buffer(self):
        for i in range(len(self.data)):
            self.data[i] = 0

    def reset(self):
        self.reset_buffer()
        self.permission = []
        self.load_fonts()
        self.load_stack()
        assert len(self.data) == self.SIZE