import os

class IllegalInstructionError(Exception):
    def __init__(self, opcode):
        msg = f"Attempted to execute an unknown opcode ({opcode:x})"
        super().__init__(msg) 

class ControlUnit:
    def __init__(self):
        self.memory = None
        self.cpu = None

        self.pc = None
        self.sp = None
        self.cir = None
        self.reset()

    def reset(self):
        self.pc = self.memory.O_ROM if self.memory else None
        self.cir = None
        self.sp = self.memory.O_STACK if self.memory else None

    def next_instruction(self):
        self.pc += 2

    def fetch(self):
        mar = self.pc
        self.next_instruction()
        mdr = self.memory.execute(mar) << 8 | self.memory.execute(mar+1)
        self.cir = mdr

    def decode_execute(self):
        opcode = self.cir
        # most significant nibble
        msn = opcode >> 12
        if msn in (3, 4, 5, 6, 7, 8, 9, 0xC, 0xD, 0xE, 0xF):
            x = (opcode & 0x0F00) >> 8
            if msn == 0xE:
                yy = opcode & 0x00FF
                if yy == 0x9E:
                    if self.cpu.context.io.keyboard.is_pressed(self.cpu.processor.v[x]):
                        self.next_instruction()
                elif yy == 0xA1:
                    if self.cpu.context.io.keyboard.is_released(self.cpu.processor.v[x]):
                        self.next_instruction()
                else:
                    raise IllegalInstructionError(opcode)
            elif msn == 0xF:
                yy = opcode & 0x00FF
                if yy == 0x07:
                    self.cpu.processor.v[x] = self.cpu.clock.timer
                elif yy == 0x0A:
                    elm = self.keyboard.has_event()
                    if not elm:
                        self.pc -= 2
                    else:
                        self.cpu.processor.v[x] = elm[0]
                elif yy == 0x15:
                    self.cpu.clock.timer = self.cpu.processor.v[x]
                elif yy == 0x18:
                    self.cpu.buzzer.timer = self.cpu.processor.v[x]
                elif yy == 0x1E:
                    self.cpu.processor.i += self.cpu.processor.v[x]
                elif yy == 0x29:
                    self.cpu.processor.i = self.cpu.processor.v[x] * 5
                elif yy == 0x33:
                    vx = self.cpu.processor.v[x]
                    self.memory[self.cpu.processor.i] = vx // 100
                    self.memory[self.cpu.processor.i+1] = (vx // 10) % 10
                    self.memory[self.cpu.processor.i+2] = (vx % 100) % 10
                elif yy == 0x55:
                    for i in range(x+1):
                        self.memory[self.cpu.processor.i + i] = self.cpu.processor.v[i]
                elif yy == 0x65:
                    for i in range(x+1):
                        self.cpu.processor.v[i] = self.memory[self.cpu.processor.i + i]
                elif opcode == 0xFFFF:
                    exit(0)
                else:
                    raise IllegalInstructionError(opcode)
            elif msn in (3, 4, 6, 7, 0xC):
                nn = opcode & 0x00FF
                if msn == 3:
                    if self.cpu.processor.v[x] == nn:
                        self.next_instruction()
                elif msn == 4:
                    if self.cpu.processor.v[x] != nn:
                        self.next_instruction()
                elif msn == 6:
                    self.cpu.processor.v[x] = nn
                elif msn == 7:
                    self.cpu.processor.v[x] = (self.cpu.processor.v[x] + nn) & 0xFF
                elif msn == 0xC:
                    self.cpu.processor.v[x] = os.urandom(1)[0] & nn
                else:
                    IllegalInstructionError(opcode)
            elif msn in (5, 8, 9, 0xD):
                y = (opcode & 0x00F0) >> 4
                if msn == 5:
                    if self.cpu.processor.v[x] == self.cpu.processor.v[y]:
                        self.next_instruction()
                elif msn == 8:
                    z = opcode & 0x000F
                    if z == 0:
                        self.cpu.processor.v[x] = self.cpu.processor.v[y]
                    elif z == 1:
                        state, result = self.cpu.alu.or_(self.cpu.processor.v[x], self.cpu.processor.v[y])
                        if state == self.cpu.alu.Status.PENDING:
                            self.pc -= 2
                        else:
                            self.cpu.processor.v[x], unused = result
                    elif z == 2:
                        state, result = self.cpu.alu.and_(self.cpu.processor.v[x], self.cpu.processor.v[y])
                        if state == self.cpu.alu.Status.PENDING:
                            self.pc -= 2
                        else:
                            self.cpu.processor.v[x], unused = result
                    elif z == 3:
                        state, result = self.cpu.alu.xor(self.cpu.processor.v[x], self.cpu.processor.v[y])
                        if state == self.cpu.alu.Status.PENDING:
                            self.pc -= 2
                        else:
                            self.cpu.processor.v[x], unused = result
                    elif z == 4:
                        state, result = self.cpu.alu.add(self.cpu.processor.v[x], self.cpu.processor.v[y])
                        if state == self.cpu.alu.Status.PENDING:
                            self.pc -= 2
                        else:
                            self.cpu.processor.v[x], self.cpu.processor.cf = result
                    elif z == 5:
                        state, result = self.cpu.alu.sub(self.cpu.processor.v[x], self.cpu.processor.v[y])
                        if state == self.cpu.alu.Status.PENDING:
                            self.pc -= 2
                        else:
                            self.cpu.processor.v[x], self.cpu.processor.cf = result
                    elif z == 6:
                        state, result = self.cpu.alu.sar(self.cpu.processor.v[x])
                        if state == self.cpu.alu.Status.PENDING:
                            self.pc -= 2
                        else:
                            self.cpu.processor.v[x], self.cpu.processor.cf = result
                    elif z == 7:
                        state, result = self.cpu.alu.sub(self.cpu.processor.v[y], self.cpu.processor.v[x])
                        if state == self.cpu.alu.Status.PENDING:
                            self.pc -= 2
                        else:
                            self.cpu.processor.v[x], self.cpu.processor.cf = result
                    elif z == 0xE:
                        state, result = self.cpu.alu.sal(self.cpu.processor.v[x])
                        if state == self.cpu.alu.Status.PENDING:
                            self.pc -= 2
                        else:
                            self.cpu.processor.v[x], self.cpu.processor.cf = result
                    else:
                        raise IllegalInstructionError(opcode)
                elif msn == 9:
                    if self.cpu.processor.v[x] != self.cpu.processor.v[y]:
                        self.next_instruction()
                elif msn == 0xD:
                    n = opcode & 0x000F
                    self.cpu.processor.cf = self.cpu.context.io.display.update(
                        self.cpu.processor.i, 
                        self.cpu.processor.v[y], 
                        self.cpu.processor.v[x], 
                        n
                    )
                else:
                    raise IllegalInstructionError(opcode)
        elif msn in (0, 1, 2, 0xA, 0xB):
            if opcode == 0x00E0:
                self.cpu.context.io.display.clear()
            elif opcode == 0x00E1:
                self.cpu.alu.reset()
            elif opcode == 0x00EE:
                tmp = self.memory[self.sp] << 8
                self.sp -= 1
                tmp |= (self.memory[self.sp])
                self.sp -= 1
                self.pc = tmp
            else:
                n = opcode & 0x0FFF
                if msn == 0:
                    if n == 0x0:
                        se = self.cpu.context.secure_element
                        se.reset()
                        se.set_context(
                            i=self.cpu.processor.i,
                            memory=self.memory.data[Memory.O_STACK:Memory.SIZE]
                        )
                        se.exc_encrypt()
                        self.cpu.processor.v[0xF] = se.cpu.tick
                    elif not self._secure_mode and n == 0x1:
                        if self.cpu.processor.i+10+len(FLAG) >= Memory.SIZE:
                            raise MemoryError("Not enought memory space")
                        se = self.cpu.context.secure_element
                        se.reset()
                        se.set_context(
                            i=self.cpu.processor.i,
                            memory=self.memory.data[Memory.O_STACK:Memory.SIZE]
                        )
                        flag = se.exc_verify()
                        self.cpu.processor.v[0xF] = se.v[0xF]
                        if se.v[0xF] == 0:
                            self.memory.data[self.cpu.processor.i+10:self.cpu.processor.i+10+len(flag)] = flag 
                    else:
                        IllegalInstructionError(opcode)
                elif msn == 1:
                    self.pc = n
                elif msn == 2:
                    # push $pc
                    self.sp += 1
                    self.memory[self.sp] = self.pc & 0x00FF
                    self.sp += 1
                    self.memory[self.sp] = self.pc >> 8
                    self.pc = n
                elif msn == 0xA:
                    self.cpu.processor.i = n
                elif msn == 0xB:
                    self.pc = n + self.cpu.processor.v[0]
                else:
                    raise IllegalInstructionError(opcode)
        else:
            raise IllegalInstructionError(opcode)

    def cycle(self):
        self.fetch()
        self.decode_execute()
        # self.cpu.update_tick()