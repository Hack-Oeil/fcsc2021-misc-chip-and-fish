import collections

class Register(collections.UserList):
    def __init__(self, length):
        super().__init__(0 for unused in range(length))

    def __getitem__(self, k):
        raise NotImplementedError

    def __setitem__(self, k, v):
        raise NotImplementedError

class Register8(Register):
    def __getitem__(self, k):
        return self.data[k] & 0xFF

    def __setitem__(self, k, v):
        self.data[k] = v & 0xFF

class Register12(Register):
    def __getitem__(self, k):
        return self.data[k] & 0x0FFF

    def __setitem__(self, k, v):
        self.data[k] = v & 0x0FFF

class Processor:
    def __init__(self):
        self.v = None
        self._tick = None
        self._i = None
        self.reset()

    def reset(self):
        self.v = Register8(16)
        self._i = Register12(1)
        self._tick = Register8(1)

    @property
    def cf(self):
        return 1 if self.v[0xF] else 0

    @cf.setter
    def cf(self, v):
        self.v[0xF] = 1 if v else 0

    @property
    def i(self):
        return self._i[0]

    @i.setter
    def i(self, v):
        self._i[0] = v

    @property
    def tick(self):
        return self._tick[0]

    @tick.setter
    def tick(self, v):
        self._tick[0] = v

    def update_tick(self):
        self.tick = self.tick + 1