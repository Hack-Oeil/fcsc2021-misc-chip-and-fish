import emulator
import sys

from flag import FLAG_LV1
from components.memory import Memory

def main():
    vm = emulator.Emulator()
    sys.stdout.write("hex encoded rom:\n")
    sys.stdout.flush()
    data = sys.stdin.readlines(1)[0]
    vm.untrusted_ctx.memory.data[Memory.O_STACK:Memory.O_STACK + len(FLAG_LV1)] = FLAG_LV1
    vm.load(data)
    vm.run()
    
if __name__ == "__main__":
    main()