preco_encrypt = """
"""

preco_verify  = """
"""